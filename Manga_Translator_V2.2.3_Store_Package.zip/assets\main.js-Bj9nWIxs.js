import{l as m}from"./logger-CR2mvg0l.js";import{s as _}from"./state-NPA1-GJP.js";const D=["#novel_honbun p",".p-novel__body p",".novel_view p","p.novel_view",'[class*="honbun"] p'];function L(){let n=[],t=new Set;for(const e of D)document.querySelectorAll(e).forEach(o=>{!t.has(o)&&o.textContent.trim().length>0&&(t.add(o),n.push(o))});return n.length===0&&(n=Array.from(document.querySelectorAll("p")).filter(e=>{const o=e.textContent.trim();return o.length>0&&/[\u3040-\u9FFF]/.test(o)})),n}function N(n){n.forEach((t,e)=>{if(t.querySelector(".mt-novel-trans"))return;const o=document.createElement("div");o.className="mt-novel-trans mt-novel-placeholder",o.dataset.idx=e,o.style.cssText="color: #8d80f1; font-size: 0.9em; margin-top: 4px; opacity: 0.6;",o.textContent="⏳",t.appendChild(o)})}function O(){if(document.getElementById("mt-novel-styles"))return;const n=document.createElement("style");n.id="mt-novel-styles",n.textContent=`
        .mt-glossary-dialog {
            position: fixed;
            top: 50%; left: 50%; transform: translate(-50%, -50%);
            background: white; color: #242424;
            padding: 20px; border-radius: 12px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.3);
            z-index: 2147483647; width: 280px;
            display: flex; flex-direction: column; gap: 12px;
            font-family: sans-serif;
        }
        @media (prefers-color-scheme: dark) {
            .mt-glossary-dialog { background: #333; color: white; }
        }
        .mt-glossary-dialog h3 { margin: 0; font-size: 16px; }
        .mt-glossary-dialog input {
            padding: 8px; border-radius: 6px; border: 1px solid #ccc;
            background: transparent; color: inherit;
        }
        .mt-glossary-dialog .btns { display: flex; gap: 8px; justify-content: flex-end; }
        .mt-glossary-dialog button {
            padding: 6px 12px; border-radius: 6px; border: none; cursor: pointer;
        }
        .mt-glossary-dialog .save { background: #0078d4; color: white; }
    `,document.head.appendChild(n)}async function P(){O();const{mangaKey:n}=await new Promise(o=>chrome.runtime.sendMessage({action:"getTabMangaKey"},o));if(!n){alert("無法識別作品標題，請重新整理頁面再試");return}const t=document.createElement("div");t.className="mt-glossary-dialog",t.innerHTML=`
        <h3>新增語彙</h3>
        <input type="text" id="mt-ori" placeholder="日文原文 (如: ラインフェルト)">
        <input type="text" id="mt-trans" placeholder="中文譯名 (如: 萊因哈特)">
        <div class="btns">
            <button class="cancel">取消</button>
            <button class="save">儲存</button>
        </div>
    `,document.body.appendChild(t);const e=()=>t.remove();t.querySelector(".cancel").onclick=e,t.querySelector(".save").onclick=async()=>{const o=t.querySelector("#mt-ori").value.trim(),a=t.querySelector("#mt-trans").value.trim();if(!o||!a)return;const r=await new Promise(s=>chrome.runtime.sendMessage({action:"saveGlossaryTerm",mangaKey:n,ori:o,trans:a},s));r.success?(alert(`已儲存: ${o} -> ${a}
下次翻譯時將會生效。`),e()):alert("儲存失敗: "+r.error)}}function I(n,t){const e=document.querySelector(`.mt-novel-trans[data-idx="${n}"]`);if(!e)return;e.textContent=t,e.classList.remove("mt-novel-placeholder"),e.style.opacity="1";const o=document.createElement("span");o.textContent=" 📚+",o.title="新增至語彙庫",o.style.cssText="cursor: pointer; font-size: 11px; margin-left: 5px; opacity: 0.5; color: #0078d4; font-weight: bold;",o.onclick=()=>P(),e.appendChild(o)}function $(){const n=Array.from(document.querySelectorAll("a[href]"));let t={prev:null,next:null};const e=["next","下一話","下一章","下一页","次へ","次",">","»","forward"],o=["prev","previous","上一話","上一章","上一页","前へ","前","<","«","back"];for(const a of n){const r=(a.innerText||a.title||"").toLowerCase().trim(),s=a.href;if(!(!s||s.startsWith("javascript:")||s===window.location.href||s.includes("#"))&&(!t.next&&e.some(l=>r.includes(l))&&(r.length>0||a.closest(".nav, .navigation, .pagination, .chapter-nav"))&&(t.next=s),!t.prev&&o.some(l=>r.includes(l))&&(r.length>0||a.closest(".nav, .navigation, .pagination, .chapter-nav"))&&(t.prev=s),t.next&&t.prev))break}return t}let c=null,p=null,x=0,v=0,C=!1;function j(){c?E():F()}function F(){c=document.createElement("div"),c.id="mt-manga-overlay",c.style.position="fixed",c.style.top="0",c.style.left="0",c.style.width="100vw",c.style.height="100vh",c.style.backgroundColor="rgba(0, 0, 0, 0.4)",c.style.cursor="crosshair",c.style.zIndex="2147483647",p=document.createElement("div"),p.id="mt-manga-selectionBox",p.style.position="fixed",p.style.border="2px dashed #008CBA",p.style.backgroundColor="rgba(0, 140, 186, 0.2)",p.style.display="none",p.style.zIndex="2147483647",c.appendChild(p),c.addEventListener("mousedown",H),c.addEventListener("mousemove",U),c.addEventListener("mouseup",q),c.addEventListener("contextmenu",n=>{n.preventDefault(),E()}),document.body.appendChild(c)}function E(){c&&(c.remove(),c=null,p=null)}function H(n){n.button===0&&(C=!0,x=n.clientX,v=n.clientY,p.style.left=`${x}px`,p.style.top=`${v}px`,p.style.width="0px",p.style.height="0px",p.style.display="block",chrome.runtime.sendMessage({action:"PRE_CAPTURE_FOR_SELECTION"}))}function U(n){if(!C)return;const t=n.clientX,e=n.clientY,o=Math.abs(t-x),a=Math.abs(e-v),r=Math.min(t,x),s=Math.min(e,v);p.style.width=`${o}px`,p.style.height=`${a}px`,p.style.left=`${r}px`,p.style.top=`${s}px`}function q(n){if(!C)return;C=!1;const t=Math.abs(n.clientX-x),e=Math.abs(n.clientY-v),o=Math.min(n.clientX,x),a=Math.min(n.clientY,v);if(t>10&&e>10){const r=window.devicePixelRatio||1,s={x:Math.round(o*r),y:Math.round(a*r),width:Math.round(t*r),height:Math.round(e*r)};Y(s,p)}else E()}async function Y(n,t){t.style.border="2px solid #4CAF50",t.style.backgroundColor="rgba(76, 175, 80, 0.4)",t.style.display="flex",t.style.alignItems="center",t.style.justifyContent="center",t.style.color="#fff",t.style.fontWeight="bold",t.style.fontSize="14px",t.style.textShadow="1px 1px 2px #000",t.innerHTML='<span class="mt-loader" style="margin-right:8px; display:inline-block; width:16px; height:16px; border:2px solid #fff; border-top-color:transparent; border-radius:50%; animation:mt-spin 1s linear infinite;"></span>處理中...';const e=window.scrollX,o=window.scrollY,a={left:parseFloat(t.style.left)+e,top:parseFloat(t.style.top)+o,width:parseFloat(t.style.width),height:parseFloat(t.style.height)};chrome.runtime.sendMessage({action:"PROCESS_SCREENSHOT",rect:n},r=>{var s;if(E(),r&&r.success){const l=(s=r.result)==null?void 0:s.results;if(l&&l.length>0){const u=l.map(g=>g.translation).join(`

`);W(a,u)}else console.warn("[Manga Engine] No results found in AI response")}else console.warn("[Manga Engine] Screenshot translation failed:",r==null?void 0:r.error)})}function W(n,t){const e=document.createElement("div");e.className="mt-floating-translation",e.style.position="absolute",e.style.left=`${n.left}px`,e.style.top=`${n.top}px`,e.style.width=`${n.width}px`,e.style.height=`${n.height}px`,e.style.backgroundColor="rgba(255, 255, 255, 0.9)",e.style.color="#000",e.style.padding="5px",e.style.boxSizing="border-box",e.style.borderRadius="5px",e.style.border="2px solid #4CAF50",e.style.zIndex="2147483646",e.style.overflow="hidden",e.style.display="flex",e.style.alignItems="center",e.style.justifyContent="center",e.style.fontFamily="sans-serif",e.style.fontWeight="bold",e.style.boxShadow="0 4px 6px rgba(0,0,0,0.3)";let o=Math.max(12,Math.min(24,Math.floor(n.height/5)));e.style.fontSize=`${o}px`,e.innerText=t,e.style.cursor="pointer",e.onclick=()=>e.remove(),document.body.appendChild(e)}const R=document.createElement("style");R.innerHTML=`
@keyframes mt-spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
`;document.head.appendChild(R);function T(){const n=Array.from(document.querySelectorAll("img, canvas"));let t=[];const e=[".ts-main-image",".reading-content","#readerarea",".manga-image",".page-break",".blocks-gallery-item"];n.forEach(r=>{let s=r.naturalWidth||r.width||r.offsetWidth,l=r.naturalHeight||r.height||r.offsetHeight,u=r.src;const g=r.getAttribute("data-src")||r.getAttribute("data-lazy-src");if(g)try{g.startsWith("//")?u=window.location.protocol+g:!g.startsWith("http")&&!g.startsWith("data:")?u=new URL(g,window.location.href).href:u=g}catch{u=g}if(r.tagName.toLowerCase()==="canvas")try{u=r.toDataURL("image/jpeg")}catch{}const S=s<300||l<300,b=["emoji","avatar","icon","logo","ads","button","banner"].some(i=>u.toLowerCase().includes(i)),M=e.some(i=>r.closest(i));(!S||M)&&!b&&u&&!u.includes("data:image/svg+xml")&&!u.includes("data:image/gif;base64,R0lGOD")&&t.push({element:r,url:u,width:s,height:l})});const o=[...new Set(t.map(r=>r.url))],a=$();return{images:o.map(r=>({src:r})),navLinks:a}}function X(){m.info("Content-Desktop","Initializing Desktop Mode..."),_.onChanged(n=>{if(n.novelResults){const t=n.novelResults.newValue;if(t&&t.length>0){const e=t[t.length-1];e.isManga||I(e.idx,e.translation)}}}),chrome.runtime.onMessage.addListener((n,t,e)=>{if((n.action==="translateNovelPage"||n.action==="AUTO_TRANSLATE_PAGE")&&(V(),e({started:!0})),n.action==="crawlImages"){const o=T();e({images:o.images,navLinks:o.navLinks})}if(n.action==="fetchBase64")return G(n.url,e),!0;n.action==="toggleSelectionMode"&&(chrome.runtime.sendMessage({action:"PRE_CAPTURE_FOR_SELECTION"},o=>{m.info("Content-Desktop","Pre-capture response received",o),j()}),e({started:!0})),n.action==="TITLE_DETECTED"&&m.info("Content-Desktop",`當前作品已識別：${n.payload.displayName}`)}),m.info("Content-Desktop","Desktop Mode initialized.")}function G(n,t){if(!/^(https?:|blob:|data:)/i.test(n)){t({error:"Blocked: unsupported URL protocol"});return}fetch(n).then(e=>e.blob()).then(e=>{const o=new FileReader;o.onloadend=()=>t({base64:o.result.split(",")[1]}),o.onerror=()=>t({error:"FileReader failed"}),o.readAsDataURL(e)}).catch(e=>t({error:e.message}))}function V(){const n=L();if(n.length===0)return;N(n),chrome.storage.local.remove("novelResults");const t=n.map(e=>e.textContent.trim());chrome.runtime.sendMessage({action:"ADD_TO_QUEUE",payload:{tabId:null,startIndex:0,texts:t}})}function K(){m.info("Content-Mobile","Initializing Mobile Overlay Drawer..."),_.onChanged(i=>{if(i.novelResults){const d=i.novelResults.newValue;if(m.info("Content-Mobile",`收到小說翻譯更新，結果筆數: ${(d==null?void 0:d.length)||0}`),d&&d.length>0){const h=d[d.length-1];m.info("Content-Mobile",`嘗試注入第 ${h.idx} 段翻譯`),h.isManga||I(h.idx,h.translation)}}});const n=document.createElement("div");n.id="mt-mobile-root",document.body.appendChild(n);const t=n.attachShadow({mode:"open"}),e=document.createElement("style");e.textContent=`
    :host {
      --edge-blue: #0078d4;
      --bg-acrylic: rgba(255, 255, 255, 0.85);
      --text-main: #242424;
      --radius: 12px;
    }
    @media (prefers-color-scheme: dark) {
      :host {
        --bg-acrylic: rgba(35, 35, 35, 0.9);
        --text-main: #ffffff;
      }
    }

    /* 懸浮按鈕 */
    .trigger-btn {
      position: fixed;
      bottom: 24px;
      right: 24px;
      width: 56px;
      height: 56px;
      border-radius: 28px;
      background: var(--edge-blue);
      box-shadow: 0 4px 16px rgba(0,0,0,0.3);
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: pointer;
      z-index: 2147483646;
      border: none;
      transition: transform 0.2s;
    }
    .trigger-btn:active { transform: scale(0.9); }
    .trigger-btn svg { width: 28px; height: 28px; fill: white; }

    /* 抽屜面板背景遮罩 */
    .drawer-overlay {
      position: fixed;
      top: 0; left: 0; width: 100%; height: 100%;
      background: rgba(0,0,0,0.4);
      z-index: 2147483647;
      opacity: 0;
      visibility: hidden;
      transition: opacity 0.3s;
    }
    .drawer-overlay.active {
      opacity: 1;
      visibility: visible;
    }

    /* 抽屜面板本體 */
    .drawer {
      position: fixed;
      bottom: 0; left: 0; width: 100%;
      height: 70vh;
      background: var(--bg-acrylic);
      backdrop-filter: blur(20px);
      -webkit-backdrop-filter: blur(20px);
      border-radius: 20px 20px 0 0;
      z-index: 2147483648;
      transform: translateY(100%);
      transition: transform 0.3s cubic-bezier(0.4, 0, 0.2, 1);
      display: flex;
      flex-direction: column;
      color: var(--text-main);
      box-shadow: 0 -8px 24px rgba(0,0,0,0.2);
    }
    .drawer.active { transform: translateY(0); }

    /* 面板頭部 */
    .drawer-header {
      padding: 16px;
      border-bottom: 1px solid rgba(128,128,128,0.2);
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    .drawer-header h2 { margin: 0; font-size: 18px; }
    .close-btn { background: none; border: none; color: var(--text-main); font-size: 24px; cursor: pointer; }

    /* 內容區 */
    .drawer-content {
      flex: 1;
      overflow-y: auto;
      padding: 16px;
    }
    .image-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(100px, 1fr));
      gap: 12px;
    }
    .img-item {
      aspect-ratio: 3/4;
      background: rgba(128,128,128,0.1);
      border-radius: 8px;
      overflow: hidden;
      border: 3px solid transparent;
      position: relative;
    }
    .img-item img { width: 100%; height: 100%; object-fit: cover; }
    .img-item.selected { border-color: var(--edge-blue); }
    .img-item.selected::after {
      content: "✓";
      position: absolute; top: 4px; right: 4px;
      background: var(--edge-blue); color: white;
      width: 20px; height: 20px; border-radius: 10px;
      display: flex; align-items: center; justify-content: center;
      font-size: 12px; font-weight: bold;
    }

    /* 底部操作 */
    .drawer-footer {
      padding: 16px;
      border-top: 1px solid rgba(128,128,128,0.2);
    }
    .primary-btn {
      width: 100%;
      background: var(--edge-blue);
      color: white;
      border: none;
      padding: 14px;
      border-radius: 8px;
      font-size: 16px;
      font-weight: 600;
      cursor: pointer;
    }
    .primary-btn:disabled { opacity: 0.5; }
  `,t.appendChild(e);const o=document.createElement("div");o.className="drawer-overlay";const a=document.createElement("div");a.className="drawer",a.innerHTML=`
    <div class="drawer-header">
      <h2>🎌 漫譯 V2 控制台</h2>
      <button class="close-btn">&times;</button>
    </div>
    <div class="drawer-content">
      <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px;">
        <div id="status-text" style="font-size:14px; opacity:0.7;">正在掃描圖片...</div>
        <div class="bulk-actions" style="display:flex; gap:8px;">
          <button id="select-all-btn" style="background:none; border:1px solid var(--edge-blue); color:var(--edge-blue); font-size:12px; padding:4px 8px; border-radius:4px; cursor:pointer;">全選</button>
          <button id="deselect-all-btn" style="background:none; border:1px solid rgba(128,128,128,0.5); color:var(--text-main); font-size:12px; padding:4px 8px; border-radius:4px; cursor:pointer;">取消</button>
        </div>
      </div>
      <div class="image-grid" id="drawer-grid"></div>
    </div>
    <div class="drawer-footer">
      <button class="primary-btn" id="drawer-submit" disabled>開始翻譯 (0)</button>
    </div>
  `;const r=document.createElement("button");r.className="trigger-btn",r.innerHTML='<svg viewBox="0 0 24 24"><path d="M12.87 15.07l-2.54-2.51.03-.03c1.74-1.94 2.98-4.17 3.71-6.53H17V4h-7V2H8v2H1v1.99h11.17C11.5 7.92 10.44 9.75 9 11.35 8.07 10.32 7.3 9.19 6.69 8h-2c.73 1.63 1.73 3.17 2.98 4.56l-5.09 5.02L4 19l5-5 3.11 3.11.76-2.04zM18.5 10h-2L12 22h2l1.12-3h4.75L21 22h2l-4.5-12zm-2.62 7l1.62-4.33L19.12 17h-3.24z"/></svg>',t.appendChild(o),t.appendChild(a),t.appendChild(r);let s=[];const l=new Set,u=i=>{o.classList.toggle("active",i),a.classList.toggle("active",i),i&&g()},g=()=>{const i=a.querySelector("#status-text"),d=a.querySelector("#drawer-grid");i.textContent="正在掃描圖片...",d.innerHTML="";const f=T().images;if(s=f,f.length===0){const w=L();w.length>0?(i.textContent=`偵測到 ${w.length} 段小說內容`,d.innerHTML=`
          <div style="grid-column: 1/-1; padding: 40px 20px; text-align: center;">
            <div style="font-size: 48px; margin-bottom: 16px;">📖</div>
            <div style="color: var(--text-main); margin-bottom: 24px;">這看起來是一篇小說，是否要開始翻譯？</div>
            <button id="start-novel-btn" style="background: var(--edge-blue); color: white; border: none; padding: 12px 24px; border-radius: 8px; font-size: 16px; font-weight: 600; cursor: pointer; width: 100%;">
              開始全頁翻譯
            </button>
          </div>
        `,d.querySelector("#start-novel-btn").onclick=()=>{u(!1),M()}):i.textContent="未找到可翻譯內容",b();return}i.textContent=`找到 ${f.length} 張圖片`,l.clear(),f.forEach((w,k)=>l.add(k)),f.forEach((w,k)=>{const y=document.createElement("div");y.className="img-item selected",y.innerHTML=`<img src="${w.src}" loading="lazy" referrerpolicy="no-referrer" style="width:100%; height:100%; object-fit:cover;">`,y.onclick=()=>{l.has(k)?(l.delete(k),y.classList.remove("selected")):(l.add(k),y.classList.add("selected")),b()},d.appendChild(y)}),b()},S=()=>{s.forEach((i,d)=>l.add(d)),a.querySelectorAll(".img-item").forEach(i=>i.classList.add("selected")),b()},A=()=>{l.clear(),a.querySelectorAll(".img-item").forEach(i=>i.classList.remove("selected")),b()},b=()=>{const i=a.querySelector("#drawer-submit");i.disabled=l.size===0,i.textContent=`開始翻譯 (${l.size})`};r.onclick=()=>u(!0),o.onclick=()=>u(!1),a.querySelector(".close-btn").onclick=()=>u(!1),a.querySelector("#select-all-btn").onclick=S,a.querySelector("#deselect-all-btn").onclick=A,a.querySelector("#drawer-submit").onclick=()=>{const i=Array.from(l).map(d=>s[d]);i.length!==0&&(u(!1),chrome.runtime.sendMessage({action:"START_MANGA_BATCH_PC_MODE",payload:{images:i,navLinks:results.navLinks,mobile:!0}}))},chrome.runtime.onMessage.addListener((i,d,h)=>{if((i.action==="translateNovelPage"||i.action==="AUTO_TRANSLATE_PAGE")&&(M(),h({started:!0})),i.action==="crawlImages"){const f=T();h({images:f.images,navLinks:f.navLinks})}});function M(){const i=L();i.length!==0&&chrome.storage.local.set({novelResults:[],novelQueue:[],isProcessingNovel:!1},()=>{N(i);const d=i.map(h=>h.textContent.trim());chrome.runtime.sendMessage({action:"ADD_TO_QUEUE",payload:{startIndex:0,texts:d}})})}m.info("Content-Mobile","Mobile Overlay Drawer ready.")}function Q(){const n=/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent),t=navigator.platform==="MacIntel"&&navigator.maxTouchPoints>1,e=window.innerWidth<=1280&&("ontouchstart"in window||navigator.maxTouchPoints>0);return n||t||e}function z(){const n=Q();m.info("Content",`系統啟動 - 偵測到環境: ${n?"行動端":"電腦端"}`),n?K():X()}document.readyState==="complete"||document.readyState==="interactive"?z():window.addEventListener("load",z);
