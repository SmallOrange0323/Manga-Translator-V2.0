import{l as h}from"./logger-CR2mvg0l.js";import{s as L}from"./state-NPA1-GJP.js";const R=["#novel_honbun p",".p-novel__body p",".novel_view p","p.novel_view",'[class*="honbun"] p'];function k(){let t=[],n=new Set;for(const e of R)document.querySelectorAll(e).forEach(o=>{!n.has(o)&&o.textContent.trim().length>0&&(n.add(o),t.push(o))});return t.length===0&&(t=Array.from(document.querySelectorAll("p")).filter(e=>{const o=e.textContent.trim();return o.length>0&&/[\u3040-\u9FFF]/.test(o)})),t}function z(t){t.forEach((n,e)=>{if(n.querySelector(".mt-novel-trans"))return;const o=document.createElement("div");o.className="mt-novel-trans mt-novel-placeholder",o.dataset.idx=e,o.style.cssText="color: #8d80f1; font-size: 0.9em; margin-top: 4px; opacity: 0.6;",o.textContent="⏳",n.appendChild(o)})}function D(){if(document.getElementById("mt-novel-styles"))return;const t=document.createElement("style");t.id="mt-novel-styles",t.textContent=`
        .mt-glossary-dialog {
            position: fixed;
            top: 50%; left: 50%; transform: translate(-50%, -50%);
            background: white; color: #242424;
            padding: 20px; border-radius: 12px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.3);
            z-index: 2147483647; width: 280px;
            display: flex; flex-direction: column; gap: 12px;
            font-family: sans-serif;
        }
        @media (prefers-color-scheme: dark) {
            .mt-glossary-dialog { background: #333; color: white; }
        }
        .mt-glossary-dialog h3 { margin: 0; font-size: 16px; }
        .mt-glossary-dialog input {
            padding: 8px; border-radius: 6px; border: 1px solid #ccc;
            background: transparent; color: inherit;
        }
        .mt-glossary-dialog .btns { display: flex; gap: 8px; justify-content: flex-end; }
        .mt-glossary-dialog button {
            padding: 6px 12px; border-radius: 6px; border: none; cursor: pointer;
        }
        .mt-glossary-dialog .save { background: #0078d4; color: white; }
    `,document.head.appendChild(t)}async function P(){D();const{mangaKey:t}=await new Promise(o=>chrome.runtime.sendMessage({action:"getTabMangaKey"},o));if(!t){alert("無法識別作品標題，請重新整理頁面再試");return}const n=document.createElement("div");n.className="mt-glossary-dialog",n.innerHTML=`
        <h3>新增語彙</h3>
        <input type="text" id="mt-ori" placeholder="日文原文 (如: ラインフェルト)">
        <input type="text" id="mt-trans" placeholder="中文譯名 (如: 萊因哈特)">
        <div class="btns">
            <button class="cancel">取消</button>
            <button class="save">儲存</button>
        </div>
    `,document.body.appendChild(n);const e=()=>n.remove();n.querySelector(".cancel").onclick=e,n.querySelector(".save").onclick=async()=>{const o=n.querySelector("#mt-ori").value.trim(),r=n.querySelector("#mt-trans").value.trim();if(!o||!r)return;const s=await new Promise(u=>chrome.runtime.sendMessage({action:"saveGlossaryTerm",mangaKey:t,ori:o,trans:r},u));s.success?(alert(`已儲存: ${o} -> ${r}
下次翻譯時將會生效。`),e()):alert("儲存失敗: "+s.error)}}function _(t,n){const e=document.querySelector(`.mt-novel-trans[data-idx="${t}"]`);if(!e)return;e.textContent=n,e.classList.remove("mt-novel-placeholder"),e.style.opacity="1";const o=document.createElement("span");o.textContent=" 📚+",o.title="新增至語彙庫",o.style.cssText="cursor: pointer; font-size: 11px; margin-left: 5px; opacity: 0.5; color: #0078d4; font-weight: bold;",o.onclick=()=>P(),e.appendChild(o)}let l=null,d=null,y=0,x=0,C=!1;function O(){l?E():$()}function $(){l=document.createElement("div"),l.id="mt-manga-overlay",l.style.position="fixed",l.style.top="0",l.style.left="0",l.style.width="100vw",l.style.height="100vh",l.style.backgroundColor="rgba(0, 0, 0, 0.4)",l.style.cursor="crosshair",l.style.zIndex="2147483647",d=document.createElement("div"),d.id="mt-manga-selectionBox",d.style.position="fixed",d.style.border="2px dashed #008CBA",d.style.backgroundColor="rgba(0, 140, 186, 0.2)",d.style.display="none",d.style.zIndex="2147483647",l.appendChild(d),l.addEventListener("mousedown",j),l.addEventListener("mousemove",F),l.addEventListener("mouseup",H),l.addEventListener("contextmenu",t=>{t.preventDefault(),E()}),document.body.appendChild(l)}function E(){l&&(l.remove(),l=null,d=null)}function j(t){t.button===0&&(C=!0,y=t.clientX,x=t.clientY,d.style.left=`${y}px`,d.style.top=`${x}px`,d.style.width="0px",d.style.height="0px",d.style.display="block",chrome.runtime.sendMessage({action:"PRE_CAPTURE_FOR_SELECTION"}))}function F(t){if(!C)return;const n=t.clientX,e=t.clientY,o=Math.abs(n-y),r=Math.abs(e-x),s=Math.min(n,y),u=Math.min(e,x);d.style.width=`${o}px`,d.style.height=`${r}px`,d.style.left=`${s}px`,d.style.top=`${u}px`}function H(t){if(!C)return;C=!1;const n=Math.abs(t.clientX-y),e=Math.abs(t.clientY-x),o=Math.min(t.clientX,y),r=Math.min(t.clientY,x);if(n>10&&e>10){const s=window.devicePixelRatio||1,u={x:Math.round(o*s),y:Math.round(r*s),width:Math.round(n*s),height:Math.round(e*s)};U(u,d)}else E()}async function U(t,n){n.style.border="2px solid #4CAF50",n.style.backgroundColor="rgba(76, 175, 80, 0.4)",n.style.display="flex",n.style.alignItems="center",n.style.justifyContent="center",n.style.color="#fff",n.style.fontWeight="bold",n.style.fontSize="14px",n.style.textShadow="1px 1px 2px #000",n.innerHTML='<span class="mt-loader" style="margin-right:8px; display:inline-block; width:16px; height:16px; border:2px solid #fff; border-top-color:transparent; border-radius:50%; animation:mt-spin 1s linear infinite;"></span>處理中...';const e=window.scrollX,o=window.scrollY,r={left:parseFloat(n.style.left)+e,top:parseFloat(n.style.top)+o,width:parseFloat(n.style.width),height:parseFloat(n.style.height)};chrome.runtime.sendMessage({action:"PROCESS_SCREENSHOT",rect:t},s=>{var u;if(E(),s&&s.success){const a=(u=s.result)==null?void 0:u.results;if(a&&a.length>0){const p=a.map(v=>v.translation).join(`

`);q(r,p)}else console.warn("[Manga Engine] No results found in AI response")}else console.warn("[Manga Engine] Screenshot translation failed:",s==null?void 0:s.error)})}function q(t,n){const e=document.createElement("div");e.className="mt-floating-translation",e.style.position="absolute",e.style.left=`${t.left}px`,e.style.top=`${t.top}px`,e.style.width=`${t.width}px`,e.style.height=`${t.height}px`,e.style.backgroundColor="rgba(255, 255, 255, 0.9)",e.style.color="#000",e.style.padding="5px",e.style.boxSizing="border-box",e.style.borderRadius="5px",e.style.border="2px solid #4CAF50",e.style.zIndex="2147483646",e.style.overflow="hidden",e.style.display="flex",e.style.alignItems="center",e.style.justifyContent="center",e.style.fontFamily="sans-serif",e.style.fontWeight="bold",e.style.boxShadow="0 4px 6px rgba(0,0,0,0.3)";let o=Math.max(12,Math.min(24,Math.floor(t.height/5)));e.style.fontSize=`${o}px`,e.innerText=n,e.style.cursor="pointer",e.onclick=()=>e.remove(),document.body.appendChild(e)}const I=document.createElement("style");I.innerHTML=`
@keyframes mt-spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
`;document.head.appendChild(I);function N(){const t=Array.from(document.querySelectorAll("img, canvas"));let n=[];const e=[".ts-main-image",".reading-content","#readerarea",".manga-image",".page-break",".blocks-gallery-item"];return t.forEach(r=>{let s=r.naturalWidth||r.width||r.offsetWidth,u=r.naturalHeight||r.height||r.offsetHeight,a=r.src;const p=r.getAttribute("data-src")||r.getAttribute("data-lazy-src");if(p)try{p.startsWith("//")?a=window.location.protocol+p:!p.startsWith("http")&&!p.startsWith("data:")?a=new URL(p,window.location.href).href:a=p}catch{a=p}if(r.tagName.toLowerCase()==="canvas")try{a=r.toDataURL("image/jpeg")}catch{}const v=s<300||u<300,S=["emoji","avatar","icon","logo","ads","button","banner"].some(m=>a.toLowerCase().includes(m)),f=e.some(m=>r.closest(m));(!v||f)&&!S&&a&&!a.includes("data:image/svg+xml")&&!a.includes("data:image/gif;base64,R0lGOD")&&n.push({element:r,url:a,width:s,height:u})}),[...new Set(n.map(r=>r.url))].map(r=>({src:r}))}function Y(){h.info("Content-Desktop","Initializing Desktop Mode..."),L.onChanged(t=>{if(t.novelResults){const n=t.novelResults.newValue;if(n&&n.length>0){const e=n[n.length-1];e.isManga||_(e.idx,e.translation)}}}),chrome.runtime.onMessage.addListener((t,n,e)=>{if((t.action==="translateNovelPage"||t.action==="AUTO_TRANSLATE_PAGE")&&(X(),e({started:!0})),t.action==="crawlImages"){const o=N();e({images:o})}if(t.action==="fetchBase64")return W(t.url,e),!0;t.action==="toggleSelectionMode"&&(chrome.runtime.sendMessage({action:"PRE_CAPTURE_FOR_SELECTION"},o=>{h.info("Content-Desktop","Pre-capture response received",o),O()}),e({started:!0})),t.action==="TITLE_DETECTED"&&h.info("Content-Desktop",`當前作品已識別：${t.payload.displayName}`)}),h.info("Content-Desktop","Desktop Mode initialized.")}function W(t,n){if(!/^(https?:|blob:|data:)/i.test(t)){n({error:"Blocked: unsupported URL protocol"});return}fetch(t).then(e=>e.blob()).then(e=>{const o=new FileReader;o.onloadend=()=>n({base64:o.result.split(",")[1]}),o.onerror=()=>n({error:"FileReader failed"}),o.readAsDataURL(e)}).catch(e=>n({error:e.message}))}function X(){const t=k();if(t.length===0)return;z(t),chrome.storage.local.remove("novelResults");const n=t.map(e=>e.textContent.trim());chrome.runtime.sendMessage({action:"ADD_TO_QUEUE",payload:{tabId:null,startIndex:0,texts:n}})}function G(){h.info("Content-Mobile","Initializing Mobile Overlay Drawer..."),L.onChanged(i=>{if(i.novelResults){const c=i.novelResults.newValue;if(h.info("Content-Mobile",`收到小說翻譯更新，結果筆數: ${(c==null?void 0:c.length)||0}`),c&&c.length>0){const g=c[c.length-1];h.info("Content-Mobile",`嘗試注入第 ${g.idx} 段翻譯`),g.isManga||_(g.idx,g.translation)}}});const t=document.createElement("div");t.id="mt-mobile-root",document.body.appendChild(t);const n=t.attachShadow({mode:"open"}),e=document.createElement("style");e.textContent=`
    :host {
      --edge-blue: #0078d4;
      --bg-acrylic: rgba(255, 255, 255, 0.85);
      --text-main: #242424;
      --radius: 12px;
    }
    @media (prefers-color-scheme: dark) {
      :host {
        --bg-acrylic: rgba(35, 35, 35, 0.9);
        --text-main: #ffffff;
      }
    }

    /* 懸浮按鈕 */
    .trigger-btn {
      position: fixed;
      bottom: 24px;
      right: 24px;
      width: 56px;
      height: 56px;
      border-radius: 28px;
      background: var(--edge-blue);
      box-shadow: 0 4px 16px rgba(0,0,0,0.3);
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: pointer;
      z-index: 2147483646;
      border: none;
      transition: transform 0.2s;
    }
    .trigger-btn:active { transform: scale(0.9); }
    .trigger-btn svg { width: 28px; height: 28px; fill: white; }

    /* 抽屜面板背景遮罩 */
    .drawer-overlay {
      position: fixed;
      top: 0; left: 0; width: 100%; height: 100%;
      background: rgba(0,0,0,0.4);
      z-index: 2147483647;
      opacity: 0;
      visibility: hidden;
      transition: opacity 0.3s;
    }
    .drawer-overlay.active {
      opacity: 1;
      visibility: visible;
    }

    /* 抽屜面板本體 */
    .drawer {
      position: fixed;
      bottom: 0; left: 0; width: 100%;
      height: 70vh;
      background: var(--bg-acrylic);
      backdrop-filter: blur(20px);
      -webkit-backdrop-filter: blur(20px);
      border-radius: 20px 20px 0 0;
      z-index: 2147483648;
      transform: translateY(100%);
      transition: transform 0.3s cubic-bezier(0.4, 0, 0.2, 1);
      display: flex;
      flex-direction: column;
      color: var(--text-main);
      box-shadow: 0 -8px 24px rgba(0,0,0,0.2);
    }
    .drawer.active { transform: translateY(0); }

    /* 面板頭部 */
    .drawer-header {
      padding: 16px;
      border-bottom: 1px solid rgba(128,128,128,0.2);
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    .drawer-header h2 { margin: 0; font-size: 18px; }
    .close-btn { background: none; border: none; color: var(--text-main); font-size: 24px; cursor: pointer; }

    /* 內容區 */
    .drawer-content {
      flex: 1;
      overflow-y: auto;
      padding: 16px;
    }
    .image-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(100px, 1fr));
      gap: 12px;
    }
    .img-item {
      aspect-ratio: 3/4;
      background: rgba(128,128,128,0.1);
      border-radius: 8px;
      overflow: hidden;
      border: 3px solid transparent;
      position: relative;
    }
    .img-item img { width: 100%; height: 100%; object-fit: cover; }
    .img-item.selected { border-color: var(--edge-blue); }
    .img-item.selected::after {
      content: "✓";
      position: absolute; top: 4px; right: 4px;
      background: var(--edge-blue); color: white;
      width: 20px; height: 20px; border-radius: 10px;
      display: flex; align-items: center; justify-content: center;
      font-size: 12px; font-weight: bold;
    }

    /* 底部操作 */
    .drawer-footer {
      padding: 16px;
      border-top: 1px solid rgba(128,128,128,0.2);
    }
    .primary-btn {
      width: 100%;
      background: var(--edge-blue);
      color: white;
      border: none;
      padding: 14px;
      border-radius: 8px;
      font-size: 16px;
      font-weight: 600;
      cursor: pointer;
    }
    .primary-btn:disabled { opacity: 0.5; }
  `,n.appendChild(e);const o=document.createElement("div");o.className="drawer-overlay";const r=document.createElement("div");r.className="drawer",r.innerHTML=`
    <div class="drawer-header">
      <h2>🎌 漫譯 V2 控制台</h2>
      <button class="close-btn">&times;</button>
    </div>
    <div class="drawer-content">
      <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px;">
        <div id="status-text" style="font-size:14px; opacity:0.7;">正在掃描圖片...</div>
        <div class="bulk-actions" style="display:flex; gap:8px;">
          <button id="select-all-btn" style="background:none; border:1px solid var(--edge-blue); color:var(--edge-blue); font-size:12px; padding:4px 8px; border-radius:4px; cursor:pointer;">全選</button>
          <button id="deselect-all-btn" style="background:none; border:1px solid rgba(128,128,128,0.5); color:var(--text-main); font-size:12px; padding:4px 8px; border-radius:4px; cursor:pointer;">取消</button>
        </div>
      </div>
      <div class="image-grid" id="drawer-grid"></div>
    </div>
    <div class="drawer-footer">
      <button class="primary-btn" id="drawer-submit" disabled>開始翻譯 (0)</button>
    </div>
  `;const s=document.createElement("button");s.className="trigger-btn",s.innerHTML='<svg viewBox="0 0 24 24"><path d="M12.87 15.07l-2.54-2.51.03-.03c1.74-1.94 2.98-4.17 3.71-6.53H17V4h-7V2H8v2H1v1.99h11.17C11.5 7.92 10.44 9.75 9 11.35 8.07 10.32 7.3 9.19 6.69 8h-2c.73 1.63 1.73 3.17 2.98 4.56l-5.09 5.02L4 19l5-5 3.11 3.11.76-2.04zM18.5 10h-2L12 22h2l1.12-3h4.75L21 22h2l-4.5-12zm-2.62 7l1.62-4.33L19.12 17h-3.24z"/></svg>',n.appendChild(o),n.appendChild(r),n.appendChild(s);let u=[];const a=new Set,p=i=>{o.classList.toggle("active",i),r.classList.toggle("active",i),i&&v()},v=()=>{const i=r.querySelector("#status-text"),c=r.querySelector("#drawer-grid");i.textContent="正在掃描圖片...",c.innerHTML="";const g=N();if(u=g,g.length===0){const w=k();w.length>0?(i.textContent=`偵測到 ${w.length} 段小說內容`,c.innerHTML=`
          <div style="grid-column: 1/-1; padding: 40px 20px; text-align: center;">
            <div style="font-size: 48px; margin-bottom: 16px;">📖</div>
            <div style="color: var(--text-main); margin-bottom: 24px;">這看起來是一篇小說，是否要開始翻譯？</div>
            <button id="start-novel-btn" style="background: var(--edge-blue); color: white; border: none; padding: 12px 24px; border-radius: 8px; font-size: 16px; font-weight: 600; cursor: pointer; width: 100%;">
              開始全頁翻譯
            </button>
          </div>
        `,c.querySelector("#start-novel-btn").onclick=()=>{p(!1),m()}):i.textContent="未找到可翻譯內容",f();return}i.textContent=`找到 ${g.length} 張圖片`,a.clear(),g.forEach((w,M)=>a.add(M)),g.forEach((w,M)=>{const b=document.createElement("div");b.className="img-item selected",b.innerHTML=`<img src="${w.src}" loading="lazy" referrerpolicy="no-referrer" style="width:100%; height:100%; object-fit:cover;">`,b.onclick=()=>{a.has(M)?(a.delete(M),b.classList.remove("selected")):(a.add(M),b.classList.add("selected")),f()},c.appendChild(b)}),f()},T=()=>{u.forEach((i,c)=>a.add(c)),r.querySelectorAll(".img-item").forEach(i=>i.classList.add("selected")),f()},S=()=>{a.clear(),r.querySelectorAll(".img-item").forEach(i=>i.classList.remove("selected")),f()},f=()=>{const i=r.querySelector("#drawer-submit");i.disabled=a.size===0,i.textContent=`開始翻譯 (${a.size})`};s.onclick=()=>p(!0),o.onclick=()=>p(!1),r.querySelector(".close-btn").onclick=()=>p(!1),r.querySelector("#select-all-btn").onclick=T,r.querySelector("#deselect-all-btn").onclick=S,r.querySelector("#drawer-submit").onclick=()=>{const i=Array.from(a).map(c=>u[c]);i.length!==0&&(p(!1),chrome.runtime.sendMessage({action:"START_MANGA_BATCH_PC_MODE",payload:{images:i,mobile:!0}}))},chrome.runtime.onMessage.addListener((i,c,g)=>{(i.action==="translateNovelPage"||i.action==="AUTO_TRANSLATE_PAGE")&&(m(),g({started:!0}))});function m(){const i=k();i.length!==0&&chrome.storage.local.set({novelResults:[],novelQueue:[],isProcessingNovel:!1},()=>{z(i);const c=i.map(g=>g.textContent.trim());chrome.runtime.sendMessage({action:"ADD_TO_QUEUE",payload:{startIndex:0,texts:c}})})}h.info("Content-Mobile","Mobile Overlay Drawer ready.")}function V(){const t=/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent),n=navigator.platform==="MacIntel"&&navigator.maxTouchPoints>1,e=window.innerWidth<=1280&&("ontouchstart"in window||navigator.maxTouchPoints>0);return t||n||e}function A(){const t=V();h.info("Content",`系統啟動 - 偵測到環境: ${t?"行動端":"電腦端"}`),t?G():Y()}document.readyState==="complete"||document.readyState==="interactive"?A():window.addEventListener("load",A);
